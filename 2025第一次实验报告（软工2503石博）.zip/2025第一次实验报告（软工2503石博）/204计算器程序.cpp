#include<iostream>
using namespace std;
int main()
{
	cout << "Please enter the formula:";
	float x, z, i;
	char y;
	cin >> x >> y >> z;
	switch (static_cast<int>(y))
	{
	case 43://��
	{
		i = x + z;
		cout << "The resource is " << i << endl;
		break;
	}
	case 45://��
	{
		i = x - z;
		cout << "The resource is " << i << endl;
		break;
	}
	case 42://��
	{
		i = x * z;
		cout << "The resource is " << i << endl;
		break;
	}
	case 47://��
	{
		if (z == 0)
			cout << "Not defined!" << endl;
		else
		{
			i = x / z;
			cout << "The resource is " << i << endl;
		}
		break;
	}
	case 37://ȡ��
	{
		if ((static_cast<int>(x) == x && static_cast<int>(z) == z) == 1)
		{
			i = static_cast<int>(x) % static_cast<int>(z);
			cout << "The resource is " << i << endl;
		}
		else
			cout << "Not defined!" << endl;
		break;
	}
	default:
		cout << "Not defined!" << endl;
	}
	return 0;
}